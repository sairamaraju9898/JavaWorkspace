package com.rameshsoft.automation.utilities;

public class Regexdemo {
public static void main(String[] args) {
	Regexutility.isvalidphunum("9182741116");
}
}
