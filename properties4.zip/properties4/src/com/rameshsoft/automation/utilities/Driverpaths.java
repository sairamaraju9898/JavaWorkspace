package com.rameshsoft.automation.utilities;

public interface Driverpaths {
String edgekey="webdriver.edge.driver";
String edgevalue="set location for edge brwsr";
String iekey="webdriver.ie.driver";
String iealue="set location for ie brwsr";
String firefoxkey="webdriver.gecko.driver";
String firefoxvalue="set location for ffx brwsr";
String chromekey="webdriver.chrome.driver";
String chromevalue=System.getProperty("user.dir")+"\\drivers\\chromedriver.exe";
}
 