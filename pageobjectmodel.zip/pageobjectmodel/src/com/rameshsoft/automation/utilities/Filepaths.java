package com.rameshsoft.automation.utilities;

public interface Filepaths {
	String confFilepath=System.getProperty("user.dir")+"\\config.properties";
	//String orFilepath=System.getProperty("user.dir")+"\\src\\com\\rameshsoft\\automation\\appln\\objectrepository\\or.properties";
	String excelpath=System.getProperty("user.dir")+"\\src\\com\\rameshsoft\\automation\\appln\\testdata\\Testdata.xls";
	String xmlFilepath="";
	String txtFilepath="";
	}
