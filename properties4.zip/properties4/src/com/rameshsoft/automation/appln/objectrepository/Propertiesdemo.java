package com.rameshsoft.automation.appln.objectrepository;

public class Propertiesdemo {

}
