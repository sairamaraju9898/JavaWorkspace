package com.rameshsoft.automation.supporters;

import lombok.Getter;

public class lambokdemo1 {
 @Getter  int e=5;
  @Getter String string="54";
  @Getter   String cftString="uhuhb";
  public static void main(String[] args) {
	
}
}
